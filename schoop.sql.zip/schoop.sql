-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 20, 2025 at 01:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoop`
--

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `LRN` char(12) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `MiddleName` varchar(100) DEFAULT NULL,
  `LastName` varchar(100) NOT NULL,
  `Strand` enum('HUMSS','GAS','HE','ICT') NOT NULL,
  `Specialization` enum('Programming','CSS') DEFAULT NULL,
  `Grade` enum('11','12') NOT NULL,
  `Section` char(1) NOT NULL,
  `EnrolledYear` int(4) UNSIGNED NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`LRN`, `FirstName`, `MiddleName`, `LastName`, `Strand`, `Specialization`, `Grade`, `Section`, `EnrolledYear`, `Password`) VALUES
('276481593047', 'Clain', NULL, 'Florentino', 'HUMSS', NULL, '11', 'A', 2023, '$2y$10$yj8guHOASAFnYzrh5rmQhu78j1HvNRJ7ohBymmWUpVmU3pzUZ6yqK'),
('401726150119', 'Aldrin', 'Vermosa', 'Fernandez', 'ICT', 'Programming', '12', 'C', 2023, '$2y$10$LE82GPs1ofjML3MdncfCOO2hez.DYTSlipoFJ14MZBVNeOqRTKq8G'),
('593720468251', 'Jan Chloe', NULL, 'Kintay', 'HE', NULL, '11', 'D', 2023, '$2y$10$R1y6AS.kZTcsCFVbZkG/n.LGwyy4qr.9hrVpuZvXCNY4kjka7.K5K'),
('845329710584', 'Marcus', 'Zy', 'Burgo', 'ICT', 'CSS', '12', 'C', 2023, '$2y$10$S4Kq9Bq/Mr7Bu7AJFnz15OPwSMmwone/DgWC/K8jXfQ0FgYFehus.');

-- --------------------------------------------------------

--
-- Table structure for table `strands`
--

CREATE TABLE `strands` (
  `StrandID` int(11) NOT NULL,
  `StrandName` varchar(150) NOT NULL,
  `Track` varchar(50) GENERATED ALWAYS AS (case when `StrandName` in ('ICT-Programming','ICT-CSS','HE-Combo 1','HE-Combo 2') then 'TVL' else 'Academic' end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `strands`
--

INSERT INTO `strands` (`StrandID`, `StrandName`) VALUES
(2, 'GAS'),
(5, 'HE-Combo 1'),
(6, 'HE-Combo 2'),
(1, 'HUMMS'),
(4, 'ICT-CSS'),
(3, 'ICT-Programming');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `SubjectID` int(11) NOT NULL,
  `SubjectName` varchar(255) NOT NULL,
  `Grade` enum('11','12') DEFAULT NULL,
  `Semester` enum('1','2') DEFAULT NULL,
  `Track` enum('Academic','TVL') DEFAULT NULL,
  `Type` enum('Core','Applied','Immersion','Specialized') NOT NULL,
  `Strand` enum('HUMSS','GAS','ICT-Programming','ICT-CSS','HE-Combo 1','HE-Combo 2','All') NOT NULL DEFAULT 'All',
  `FormulaType` enum('Core','Academic-Other','Academic-Special','TVL') NOT NULL DEFAULT 'Core',
  `WrittenWorkWeight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `PerformanceTaskWeight` decimal(5,2) NOT NULL DEFAULT 0.00,
  `QuarterlyAssessmentWeight` decimal(5,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`SubjectID`, `SubjectName`, `Grade`, `Semester`, `Track`, `Type`, `Strand`, `FormulaType`, `WrittenWorkWeight`, `PerformanceTaskWeight`, `QuarterlyAssessmentWeight`) VALUES
(1, 'Oral Communication', '11', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(2, 'Komunikasyon at Pananaliksik sa Wika at Kulturang Pilipino', '11', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(3, 'General Mathematics', '11', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(4, 'Earth and Life Science', '11', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(5, 'Physical Education and Health', NULL, NULL, NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(6, 'Understanding Culture, Society, and Politics', '11', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(7, 'Reading and Writing', '11', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(8, 'Pagbasa at Pagsusuri ng Iba\'t Ibang Teksto Tungo sa Pananaliksik', '11', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(9, 'Statistics and Probability', '11', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(10, 'Physical Science', '11', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(11, 'Media and Information Literacy', '11', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(12, 'Introduction to the Philosophy of Human Person', '12', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(13, '21st Century Literature from the Philippines and the World', '12', '1', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(14, 'Personal Development', '12', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(15, 'Comtemporary Philippine Arts from Regions', '12', '2', NULL, 'Core', 'All', 'Core', 25.00, 50.00, 25.00),
(16, 'Computer Programming', NULL, NULL, 'TVL', 'Specialized', 'ICT-Programming', 'TVL', 20.00, 60.00, 20.00),
(17, 'Computer System Servicing', NULL, NULL, 'TVL', 'Specialized', 'ICT-CSS', 'TVL', 20.00, 60.00, 20.00),
(19, 'Empowerment Technologies', '11', '1', 'Academic', 'Applied', 'All', 'Academic-Other', 25.00, 45.00, 30.00),
(20, 'Empowerment Technologies', '11', '1', 'TVL', 'Applied', 'All', 'TVL', 20.00, 60.00, 20.00),
(21, 'Entrepreneurship', '11', '2', 'Academic', 'Applied', 'All', 'Academic-Other', 25.00, 45.00, 30.00),
(22, 'Entrepreneurship', '11', '2', 'TVL', 'Applied', 'All', 'TVL', 20.00, 60.00, 20.00),
(23, 'Practical Research', NULL, NULL, 'TVL', 'Applied', 'All', 'TVL', 20.00, 60.00, 20.00),
(24, 'Practical Research', NULL, NULL, 'Academic', 'Applied', 'All', 'Academic-Other', 25.00, 45.00, 30.00),
(25, 'English for Academic and Professional Purposes', '12', '2', 'Academic', 'Applied', 'All', 'Academic-Other', 25.00, 45.00, 30.00),
(26, 'English for Academic and Professional Purposes', '12', '2', 'TVL', 'Applied', 'All', 'TVL', 20.00, 60.00, 20.00),
(27, 'Inquiries, Investigations and Immersions', '12', '2', 'Academic', 'Immersion', 'All', 'Academic-Special', 35.00, 40.00, 25.00),
(28, 'Work Immersion', '12', '2', 'Academic', 'Immersion', 'All', 'Academic-Special', 35.00, 40.00, 25.00),
(29, 'Work Immersion', '12', '2', 'TVL', 'Immersion', 'All', 'TVL', 20.00, 60.00, 20.00);

--
-- Triggers `subject`
--
DELIMITER $$
CREATE TRIGGER `set_grading_weights` BEFORE INSERT ON `subject` FOR EACH ROW BEGIN
    -- Determine FormulaType based on Track and Type
    IF NEW.Track = 'TVL' THEN
        SET NEW.FormulaType = 'TVL';
    ELSEIF NEW.Track = 'Academic' THEN
        IF NEW.Type = 'Applied' THEN
            SET NEW.FormulaType = 'Academic-Other';
        ELSEIF NEW.Type = 'Immersion' THEN
            SET NEW.FormulaType = 'Academic-Special';
        ELSE
            SET NEW.FormulaType = 'Core';
        END IF;
    END IF;

    -- Assign weights based on FormulaType
    CASE NEW.FormulaType
        WHEN 'Core' THEN
            SET NEW.WrittenWorkWeight = 25.00,
                NEW.PerformanceTaskWeight = 50.00,
                NEW.QuarterlyAssessmentWeight = 25.00;
        WHEN 'Academic-Other' THEN
            SET NEW.WrittenWorkWeight = 25.00,
                NEW.PerformanceTaskWeight = 45.00,
                NEW.QuarterlyAssessmentWeight = 30.00;
        WHEN 'Academic-Special' THEN
            SET NEW.WrittenWorkWeight = 35.00,
                NEW.PerformanceTaskWeight = 40.00,
                NEW.QuarterlyAssessmentWeight = 25.00;
        WHEN 'TVL' THEN
            SET NEW.WrittenWorkWeight = 20.00,
                NEW.PerformanceTaskWeight = 60.00,
                NEW.QuarterlyAssessmentWeight = 20.00;
        ELSE
            SET NEW.WrittenWorkWeight = 0.00,
                NEW.PerformanceTaskWeight = 0.00,
                NEW.QuarterlyAssessmentWeight = 0.00;
    END CASE;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `TeacherID` char(7) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `MiddleName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Role` enum('admin','teacher') DEFAULT 'teacher',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`TeacherID`, `FirstName`, `MiddleName`, `LastName`, `Email`, `Password`, `Role`, `created_at`) VALUES
('8364721', 'Benedict Mikee', NULL, 'Solon', 'ven.squimay@gmail.com', '$2y$10$n/o.C8Ey5MpOdBGsrpWSeO.5pcZLLjy6n1XqSD7IEsMdOzrbujnE6', 'admin', '2025-02-17 14:59:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`LRN`);

--
-- Indexes for table `strands`
--
ALTER TABLE `strands`
  ADD PRIMARY KEY (`StrandID`),
  ADD UNIQUE KEY `UNIQUE` (`StrandName`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`SubjectID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`TeacherID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `strands`
--
ALTER TABLE `strands`
  MODIFY `StrandID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `SubjectID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
